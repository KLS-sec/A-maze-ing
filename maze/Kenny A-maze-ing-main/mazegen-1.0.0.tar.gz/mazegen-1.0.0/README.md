*This project has been created as part of the 42 curriculum by lching, kbrun.*

# Description  
We implemented a **maze generator in Python** that takes a *configuration file*, generates a maze, usually perfect (with a single path connecting all parts of the maze), and writes it to a file using a hexadecimal wall representation. We also made a visual of the maze in ASCII representation and organized our code so that the generation logic can be reused later.  
By using a config.txt file as an argument given to the program, we will generate the labyrinth depending on the option given in the text file : its width, height, the entry and exit point, the name of the output file, if the labyrinth is perfect or not, the seed used to generate the same labyrinth and which algorithm we used to generate the labyrinth and the shortest path to the exit.
We also generate an output file named **maze.txt** which gives an hexadecimal representation of the labyrinth followed by the entry point, the exit point and the shortest valid path from entry to exit, written with a succession of **N(orth), S(outh), E(ast), W(est).


# Instructions  
Use the command **"python3 a_maze_ing.py config.txt"** to launch the program if all dependancies from requirements.txt are already installed.

Another way to launch it without dependancies, is to use the command **"make install"** as it will create a virtual environment with all the conditions necessary to launch the program.

The second command to use would be **"make run"**, which should lead to the creation of the maze and the path from entry to exit if all parameters from *config.txt* had been correctly set up, as well as a *menu* from 1 to 4, where the user can choose one of which to change the output of the labyrinth :
- **1** : Change the *arrangement* of the labyrinth, usually leading to a new path from entry to exit too, without changing any base parameters.
- **2** : Change only the color of the font, the 42 pattern (if visible) and the walls of the labyrinth from a preset *ANSI CODES*.
- **3** : Show or Hide the path from *start* (in green) to *end point* (in yellow).
- **4** : *Reset* the terminal to its base color and *exit* the program.

There is also **"make debug"** to get to the debugger pdb and test the file as it is, line by line.

**"make clean / uninstall"** are used to remove cached datas or temporary files, while the 2nd command **"uninstalled"** especially remove also the virtual environment.

Finally, **"make lint / lint-strict"** are commands to type-check with *mypy* and see all *flake8* errors, the first one having a few flags to check our files while the 2nd is checking everything.
# Resources
A video to understand the basic concept of some possible choices of algorithm to [generate a maze](https://www.youtube.com/watch?v=ioUl1M77hww).

Another one to see how the breadth first search algorithm works to look for the [shortest path to solution](https://www.youtube.com/watch?v=V1oZQm1HtVw).

AI was used to correct a few mistakes we made on the way and to improve our understanding of how to not miss those kinds of mistakes anymore. 

# Additional Sections
## Config.txt
**config.txt** is a text file that setup the maze outlines with some basic parameters such as height and width or entry and exit.

If some changes needs to be done for the config.txt file, here is a basic example of how to handle the configurations of all parameters :
- WIDTH=*integer*
- HEIGHT=*integer*
- ENTRY=*integer*,*integer*
- EXIT=*integer*,*integer*
- OUTPUT_FILE=*maze.txt*
- PERFECT=*True or False*
- SEED=*integer*
- ALGORITHM=*"Backtracking"* (shouldn't be changed to create the maze)

## Algorithm chosen
DFS (Depth-First Search)
BFS (Breadth First Search)

## Reusability

## Management
### Planning


### Improvement


### Tools used

### Contributions
**lching** contributed to the project by doing...  
**kbrun** contributed to the project by doing...
